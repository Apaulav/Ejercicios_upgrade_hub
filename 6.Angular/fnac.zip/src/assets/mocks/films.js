export const films = [
  {
    "title": "Star Wars: Episodio I - La amenaza fantasma",
    "director": "George Lucas",
    "duration": 120,
    "year": 1999,
    "actors": [
      "Jake Lloyd",
      "Natalie Portman",
      "Liam Neeson"
    ]
  },
  {
    "title": "Star Wars: Episodio 2 - Las Guerras Clone",
    "director": "George Lucas",
    "duration": 120,
    "year": 2001,
    "actors": [
      "Jake Lloyd",
      "Natalie Portman",
      "Liam Neeson"
    ]
  },
  {
    "title": "Star Wars: Episodio 3 - La Venganza de los Sith",
    "director": "George Lucas",
    "duration": 120,
    "year": 2001,
    "actors": [
      "Jake Lloyd",
      "Natalie Portman",
      "Liam Neeson"
    ]
  },
  {
    "title": "Star Wars: Episodio 4 - Una Nueva Esperanza",
    "director": "George Lucas",
    "duration": 120,
    "year": 2001,
    "actors": [
      "Jake Lloyd",
      "Natalie Portman",
      "Liam Neeson"
    ]
  },
  {
    "title": "Star Wars: Episodio 5 - El Imperio Contraataca",
    "director": "George Lucas",
    "duration": 120,
    "year": 2001,
    "actors": [
      "Jake Lloyd",
      "Natalie Portman",
      "Liam Neeson"
    ]
  },
  {
    "title": "Star Wars: Episodio 6- El Retorno del Jedi",
    "director": "George Lucas",
    "duration": 120,
    "year": 2001,
    "actors": [
      "Jake Lloyd",
      "Natalie Portman",
      "Liam Neeson"
    ]
  }
];
