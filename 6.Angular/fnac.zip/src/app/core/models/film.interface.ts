export interface IFilm {
  title: string;
  director: string;
  duration: number;
  year: number;
  actors: string[];
}
