import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discs',
  templateUrl: './discs.component.html',
  styleUrls: ['./discs.component.scss']
})
export class DiscsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
